# Query-coordinator
Installs the query-coordinator container by itself without all of the production level components. This component receives a request, splits it into batches and forwards them to most appropriate Spatial API for processing.

# Container Image
*To be decided*

## Prerequisites

    Helm v3.7.0
    Kubernetes 1.19+

## Recommended Pre-requisites
In addition to minimum:

    Istio [v1.11.4]
    Keda [v2.4]

## This works with
    Spatial API

## Installation

```
cd querycoordinator/
helm install --create-namespace --namespace querycoordinator querycoordinator .
```

# Notes
* *Ingress or Istio-*
You can install the chart with either Istio or an Ingress.
If you want to use Ingress, you will need an Ingress controller. Enabling Ingress has the effect of only creating the resource into your cluster.
_[Read more](https://kubernetes.io/docs/concepts/services-networking/ingress/#prerequisites) about the pre-requisites for getting Ingress to work._

* *Autoscaling-* You can use either KEDA or HPA not both. Default is set to KEDA.
_[Read more](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/) about HPA and [Learn more](https://keda.sh/resources/) about KEDA_
