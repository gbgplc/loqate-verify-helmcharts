# InstallAIData

Runs the InstallAIData job to download data in preparation for running spatial-api.

## Prerequisites

- Helm v3.7.0
- Kubernetes 1.19+

### Data Storage

Currently, to store all the data you will need at least 4Gi of storage and downloading it will take 5-15 minutes.

This chart will install the data on a Persistent Volume (PV).  The provided yaml files mount a local volume and will need updating/replacing with the details of your PV.  The `values.yaml` files for both charts have `storage` properties for configuring the PV.  

## Installation

Assuming you are in the `installaidata` folder:

``` bash

```

## Important Values

IMPORTANT FOR THE FUTURE: Path to install data, this must be identical in the AI Parse configuration:

```yml
app:
  dataFolder: "/data"
```
