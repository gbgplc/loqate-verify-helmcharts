# memberlist
Spins up a service which uses the specified selector to find all related memberlist nodes.
