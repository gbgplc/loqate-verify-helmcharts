{{/*
Expand the name of the chart.
*/}}
{{- define "lqt-spatial-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "lqt-spatial-api.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "lqt-spatial-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "lqt-spatial-api.labels" -}}
helm.sh/chart: {{ include "lqt-spatial-api.chart" . }}
{{ include "lqt-spatial-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{/* dataset to make available */}}
dataset: {{ .Values.verify.dataset }}
{{/* is it a premium dataset */}}
premium: {{ .Values.verify.premium | quote }}
{{/* app: {{ include "lqt-spatial-api.name" . }} */}}
app: {{ default .Chart.Name .Values.nameOverride }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "lqt-spatial-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "lqt-spatial-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Values.memberlist.enabled }}
memberlist: {{ .Values.memberlist.selector | quote }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "lqt-spatial-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "lqt-spatial-api.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{- define "lqt-spatial-api.dockerconfig" -}}
{{- printf "{\"auths\": {\"%s\": {\"username\": \"%s\", \"password\": \"%s\" }}}" .Values.imageCredentials.registry .Values.imageCredentials.username .Values.imageCredentials.password | b64enc }}
{{- end }}
