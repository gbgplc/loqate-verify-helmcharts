# Spatial API
Installs the spatial-api container by itself without all of the production level components.

# Container Image
[loqate-verify-spatial-api](https://github.com/gbgplc-internal/loqate-verify-spatial-api/)

## Installation

```
cd spatial-api/
helm install --create-namespace --namespace spatial-api spatial-api .
```

## Important Values

Location of locally available GKR data to mount.
```yml
storage:
  path: "/c/loqatewindows/data"
```

Setting dataset for spatial-api
```yml
verify:
  dataset: row
```

GKR data is expected to be installed separately and live somewhere on the host.

## Installation With Custom GKR Path
```
helm install --create-namespace --namespace spatial-api spatial-api --set storage.path="/c/loqate/data" .
```

## Example Request

Find your endpoint.
```
kubectl get svc --namespace lqt-spatial-api
```

### Endpoint
POST http://localhost:3000/address/verify

### Request
```json
{
    "options": {
        "aiparse": true
    },
    "input": [
        {
            "Address": "No. 403 (A1), Shwe Taung Kyar Street, Bahan Township, Yangon 11201 MY"
        }
    ]
}
```

### Response
```json
{
    "output": [
        {
            "AQI": "E",
            "AVC": "U00-I44-P2-100",
            "Address": "Bahan Township, Yangon<BR>403A 1 Shwe Taung Kyar Street<BR>11201",
            "Address1": "Bahan Township, Yangon",
            "Address2": "403A 1 Shwe Taung Kyar Street",
            "Address3": "11201",
            "Building": "Bahan Township, Yangon",
            "BuildingName": "Bahan Township, Yangon",
            "Country": "MY",
            "CountryName": "Malaysia",
            "DeliveryAddress": "Bahan Township, Yangon<BR>403A 1 Shwe Taung Kyar Street",
            "DeliveryAddress1": "Bahan Township, Yangon",
            "DeliveryAddress2": "403A 1 Shwe Taung Kyar Street",
            "HyphenClass": "A",
            "ISO31662": "MY",
            "ISO31663": "MYS",
            "ISO3166N": "458",
            "PostalCode": "11201",
            "PostalCodePrimary": "11201",
            "Premise": "403A",
            "PremiseNumber": "403A",
            "Sequence": "0",
            "Thoroughfare": "1 Shwe Taung Kyar Street",
            "ThoroughfareName": "1 Shwe Taung Kyar",
            "ThoroughfareTrailingType": "Street"
        }
    ]
}
```
