# AI Parse Python Service
Provides a simple endpoint that does some pre-processing both in the API itself and via tfserve.

# Container Image
[loqate-verify-ai-parse-service](https://github.com/gbgplc-internal/loqate-verify-ai-parse-service/)

## Installation

```
cd ai-parse/
helm install --create-namespace --namespace ai-parse ai-parse .
```

## Important Values

Location of tfserving instance to point to.
```yml
tfserveEndpoint: "http://10.108.212.59:8501"
```

## Example Request

Find your endpoint.
```
kubectl get svc --namespace ai-parse
```

![Get service](svc.png)

### Endpoint
POST http://localhost:5050/TFNER/parse

### Request
```json
{
    "Address": "No. 403 (A1), Shwe Taung Kyar Street, Bahan Township, Yangon 11201",
    "Country": "MY"
}
```

### Response
```json
{
    "Address": "No. 403 (A1), Shwe Taung Kyar Street, Bahan Township, Yangon 11201",
    "Building": "Shwe",
    "Country": "MY",
    "CountryName": "MY",
    "ISO3166-2": "MY",
    "ISO3166-3": "MYS",
    "Locality": "Yangon",
    "Parser": "TFNER",
    "PostalCode": "11201",
    "SubBuilding": "A1),",
    "Thoroughfare": "Taung Kyar Street, Bahan Township,"
}
```

2022
