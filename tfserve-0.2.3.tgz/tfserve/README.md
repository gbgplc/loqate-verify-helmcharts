# TFServe
Install tfserve with baked in Loqate models,

# Container Image
[loqate-verify-tfserve](https://github.com/gbgplc-internal/loqate-verify-tfserve/)

## Installation

```
cd tfserve/
helm install --create-namespace --namespace tfserve tfserve .
```

## Example Request

Find your endpoint.
```
kubectl get svc --namespace tfserve
```

![Get service](svc.png)

### Endpoint
POST http://localhost:5050/TFNER/parse

### Request
```json
{
    "Address": "No. 403 (A1), Shwe Taung Kyar Street, Bahan Township, Yangon 11201",
    "Country": "MY"
}
```

### Response
```json
{
    "Address": "No. 403 (A1), Shwe Taung Kyar Street, Bahan Township, Yangon 11201",
    "Building": "Shwe",
    "Country": "MY",
    "CountryName": "MY",
    "ISO3166-2": "MY",
    "ISO3166-3": "MYS",
    "Locality": "Yangon",
    "Parser": "TFNER",
    "PostalCode": "11201",
    "SubBuilding": "A1),",
    "Thoroughfare": "Taung Kyar Street, Bahan Township,"
}
```
