# InstallManager

Runs the InstallManager job to download data in preparation for running spatial-api.

## Prerequisites

- Helm v3.7.0
- Kubernetes 1.19+

### Data Storage

Currently, to store all the data you will need at least 250Gi of storage and downloading it will take 20-30 minutes.

This chart will install the data on a Persistent Volume (PV).  The provided yaml files mount a local volume and will need updating/replacing with the details of your PV.  The `values.yaml` files for both charts have `storage` properties for configuring the PV.  

## Installation

Assuming you are in the `installmanager` folder:

``` bash
helm install --create-namespace -n <NAMESPACE> <RELEASE_NAME> . --set app.licenseKey=<LICENSE KEY> --set app.products=<PRODUCTS TO INSTALL>
```

## Important Values

License key to grant access to data:

```yml
app:
  licenseKey: "EXAMPLEL-ICEN-SEKE-YGOE-SHERE0000000"
```

Products to install:

```yml
app:
  products: "KBCOMMON"
```

Path to install data, this must be identical in the spatial-api configuration:

```yml
app:
  dataFolder: "/data"
```
